# Copyright 2018 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# [START gae_python37_cloudsql_mysql]
import os

from flask import Flask, render_template, request
import pymysql

db_user = os.environ.get('CLOUD_SQL_USERNAME')
db_password = os.environ.get('CLOUD_SQL_PASSWORD')
db_name = os.environ.get('CLOUD_SQL_DATABASE_NAME')
db_connection_name = os.environ.get('CLOUD_SQL_CONNECTION_NAME')

app = Flask(__name__)


if os.environ.get('GAE_ENV') == 'standard':
        unix_socket = '/cloudsql/{}'.format(db_connection_name)
        cnx = pymysql.connect(user=db_user, password=db_password,
                              unix_socket=unix_socket, db=db_name)
else:
        host = '127.0.0.1'
        cnx = pymysql.connect(user=db_user, password=db_password,
                              host=host, db=db_name)

finalemail = ""

@app.route('/')
def main():

    with cnx.cursor() as cursor:
        cursor.execute('SELECT * from Event;')
        data = cursor.fetchall()

    return render_template('home.html', data=data)


@app.route('/Venues')
def vven():
    with cnx.cursor() as cursor:

        cursor.execute('SELECT * from Venue;')
        data = cursor.fetchall()
        
    return render_template('venue.html', data=data)

@app.route('/Login')
def tlogin():
    return render_template('Login.html')

@app.route('/Login', methods=['POST'])
def login():
    global finalemail
    email = request.form['email']
    _email = str(email)
    pwd = request.form['pwd']
    _pwd = int(pwd)
    with cnx.cursor() as cursor:
        cursor.execute('SELECT count(*) from Users where email = %s and password = %s ;',(_email,_pwd))
        d = cursor.fetchone()
        if(d!=(0,)):
            finalemail = _email
            return render_template('thome.html')
        else:
            return str("Wrong UserName or Wrong PIN")

@app.route('/userhome')
def t():
    global finalemail
    with cnx.cursor() as cursor:
        cursor.execute('SELECT * from Event;')
        data = cursor.fetchall()
        cursor.execute('SELECT eventid from Registered2 where userid = %s',[finalemail])
        registeredfor = cursor.fetchall()
    return render_template('userhome.html', data=data, femail = finalemail, registeredfor = registeredfor)


@app.route('/Signup')
def tsignup():
    return render_template('Signup.html')

@app.route('/Signup', methods=['POST'])
def signup():
    global finalemail
    email = str(request.form['email'])
    name = str(request.form['fname'])
    sname =str(request.form['sname'])
    password = int(request.form['pwd'])
    zipcode = int(request.form['zipcode'])
    phone =int(request.form['phone'])
    etype1 =str(request.form['etype1'])
    etype2 =str(request.form['etype2'])
    etype3 =str(request.form['etype3'])
    with cnx.cursor() as cursor:
        
        cursor.execute('''Insert into Users (email,name,sname,password,zipcode,phone,etype1,etype2,etype3) values (%s,%s,%s,%s,%s,%s,%s,%s,%s)''',(email,name,sname,password,zipcode,phone,etype1,etype2,etype3))
        cursor.execute('''commit;''')   
    finalemail = email;
    
    return render_template('tlogin.html')

@app.route('/create')
def tcreate():
    return render_template('create.html')

@app.route('/create', methods=['POST'])
def create():
    dt2 = '2019-08-01 13:00:00'
    global finalemail
    venue = str(request.form['venue'])
    capacity = int(request.form['capacity'])
    remaining = int(request.form['remspots'])
    fee =int(request.form['fees'])
    begin =str(request.form['bt'])
    end =str(request.form['et'])
    typ = str(request.form['type'])

    with cnx.cursor() as cursor:
        cursor.execute('''SELECT venueid FROM Venue where venuename = %s ''',[venue])
        venueid = cursor.fetchone()[0]
        cursor.execute(''' select availability from VenueSlots2 where datetime2 >= %s and datetime2 <%s AND venueid=%s''', (begin,end,venueid))
        flag=0
        for m in cursor.fetchall():
            if (m==(0,)): 
                flag=1
        if(flag==0):
            cursor.execute('''SELECT EventID FROM Event ORDER BY EventID DESC LIMIT 1 ''')
            eventid = cursor.fetchone()[0]
            eventi = eventid+1
            cursor.execute('''Insert into Event (EventID, EventCreator,Venue,Capacity,RemainingSpots, Fee_USD,Begintime,endtime,Type) values (%s,%s,%s,%s,%s,%s,%s,%s,%s)''',(eventi,finalemail,venue,capacity,remaining,fee,begin,end,typ))
            cursor.execute('''commit;''')
            cursor.execute('''Update VenueSlots2 set availability = 0, EventID = %s where venueid = %s and datetime2 between %s and %s''',(eventi,venueid,begin,end))
            cursor.execute('''commit;''')
            return render_template('thome.html')
        else:
            return("Not Available")

@app.route('/join')
def tjoin():
    return render_template('join.html')

@app.route('/join', methods=['POST'])
def join():
    with cnx.cursor() as cursor:
        global finalemail
        eventid = int(request.form['eventid'])

        cursor.execute('''select RemainingSpots from Event where EventID = %s''',[eventid])
        countone = cursor.fetchone()[0]
        cc = int(countone)
        if(cc>0):
            cursor.execute('''insert into Registered2 (eventid,userid) values (%s,%s)''',(eventid,finalemail))
            cursor.execute('''update Event set RemainingSpots = RemainingSpots -1 where EventID = %s''',[eventid])
            cursor.execute('''commit;''')
            return render_template('thome.html')
        else:
            return("Sorry Event is full")

@app.route('/unregister')
def tunregister():
    with cnx.cursor() as cursor:
        global finalemail
        cursor.execute('SELECT eventid from Registered2 where userid = %s',[finalemail])
        registeredfor = cursor.fetchall()
        if(registeredfor!=(0,)):
            return render_template('unregister.html',regis = registeredfor)
        else:
            return("You haven't registered for any Events")

@app.route('/unregister', methods=['POST'])
def unregister():
    with cnx.cursor() as cursor:
        global finalemail
        eventid = int(request.form['eventidunregis'])
        cursor.execute(''' delete from Registered2 where userid=%s and eventid =%s''',(finalemail,eventid))
        cursor.execute('''commit;''')
        return render_template('thome.html')

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True)
	